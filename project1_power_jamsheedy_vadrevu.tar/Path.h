//Project 1
//COP4610
//Venkata Sai Pavan Kumar Vadrevu, Daniel Jamsheedy, Luke Power

#include <stdio.h>
#include <stdlib.h>
#include "EnvVariables.h"
#include <unistd.h>

#ifndef PATH_H
#define PATH_H

char* pathSearch(char * command);

#endif
