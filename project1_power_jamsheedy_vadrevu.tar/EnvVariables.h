//Project 1
//COP4610
//Venkata Sai Pavan Kumar Vadrevu, Daniel Jamsheedy, Luke Power

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef ENV_VARIABLES_H
#define ENV_VARIABLES_H

void printEnvironment(char *name);
char* getEnvironment(char * name);
#endif
