//Project 1
//COP4610
//Venkata Sai Pavan Kumar Vadrevu, Daniel Jamsheedy, Luke Power

#ifndef BGPROCESS_H
#define BGPROCESS_H
#include "tokenlist.h"

int isBackgroundProcess(tokenlist* tokens);
tokenlist* getCommandFromBGProcess(tokenlist* tokens);

#endif
