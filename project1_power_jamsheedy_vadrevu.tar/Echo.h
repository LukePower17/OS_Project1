//Project 1
//COP4610
//Venkata Sai Pavan Kumar Vadrevu, Daniel Jamsheedy, Luke Power

#ifndef ECHO_H
#define ECHO_H
#include <time.h>
char *lowerCase(char *s);
int echo(tokenlist *tokens);
#endif
